### Botz By [@PredatorHackerzZ](https://t.me/TheTeleRoid)

# Bots new Version

### Special Thanks @AbirHasan2005

# Added With Batch Mode and Ban/Unban Command
° Features New Version Of Python And Modules

## € Thanks To Me By Sponsoring My Any Github Repo 
 
